/** Automatically generated file. DO NOT MODIFY */
package com.pg.pg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}